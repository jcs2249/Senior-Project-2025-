﻿//Joseph Saponaro - Current working script for the connection between the Unity game and the Html File
// Contains methods for buttons and all that stuff.

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using NativeWebSocket;
using TMPro;

public class WebSocketReceiver : MonoBehaviour
{
    private WebSocket websocket;

    public AudioSource backgroundMusic;

    public TMP_Text logText;
    public TMP_Text questionText;
    public TMP_Text leaderboardText;
    public TMP_Text usersText;
    public TMP_Text timerText;
    public TMP_Text roundText;

    public Button connectButton;
    public Button nextRoundButton;
    public Button resetScoresButton;
    public Button closeGameButton;

    private List<string> messageHistory = new List<string>();
    private const int maxMessages = 5;  // ← now only the 5 newest messages

    public float roundTime = 30f;
    private float timeLeft = 0f;
    private bool timerRunning = false;

    private int roundCount = 0;

    void Start()
    {
        connectButton.onClick.AddListener(ConnectToServer);
        nextRoundButton.onClick.AddListener(HandleNextRoundClicked);
        resetScoresButton.onClick.AddListener(() => SendHostCommand("RESET"));
        closeGameButton.onClick.AddListener(CloseGame);
        roundText.text = "Round: 0";

        if (backgroundMusic != null)
            backgroundMusic.Play();
    }

    async void ConnectToServer()
    {
        websocket = new WebSocket("wss://aarj.ngrok.io/ws");

        websocket.OnOpen += () => AddLog("Connected to server.");
        websocket.OnMessage += (bytes) =>
        {
            string message = System.Text.Encoding.UTF8.GetString(bytes);
            Debug.Log("Message: " + message);

            if (message.StartsWith("Question:"))
            {
                string q = message.Substring("Question:".Length).Trim();
                questionText.text = q;
                AddLog("Question: " + q);
                StartNewTimer();
            }
            else if (message.StartsWith("Leaderboard:"))
            {
                leaderboardText.text = message;
            }
            else if (message.StartsWith("Users:"))
            {
                string[] users = message.Substring(6).Split(',');
                usersText.text = "Users:\n" + string.Join("\n", users);
            }
            else
            {
                AddLog(message);
            }
        };

        websocket.OnClose += (e) => AddLog("Disconnected.");
        websocket.OnError += (e) => AddLog("Error: " + e);

        await websocket.Connect();
    }

    void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        websocket?.DispatchMessageQueue();
#endif

        if (timerRunning)
        {
            timeLeft -= Time.deltaTime;
            timerText.text = $"Time: {Mathf.CeilToInt(timeLeft)}";

            if (timeLeft <= 0)
            {
                timerRunning = false;
                timerText.text = "Time: 0";
                SendHostCommand("ROUNDOVER");
                AddLog("Round ended. Scoring disabled.");
            }
        }
    }

    void HandleNextRoundClicked()
    {
        roundCount++;
        roundText.text = $"Round: {roundCount}";
        SendHostCommand("NEXT");
    }

    void StartNewTimer()
    {
        timeLeft = roundTime;
        timerRunning = true;
    }

    async void SendHostCommand(string command)
    {
        if (websocket != null && websocket.State == WebSocketState.Open)
            await websocket.SendText($"HostCommand:{command}");
    }

    async void CloseGame()
    {
        if (websocket != null && websocket.State == WebSocketState.Open)
        {
            AddLog("Closing game connection...");
            await websocket.Close();
            AddLog("Disconnected.");
        }

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    void AddLog(string message)
    {
        messageHistory.Add(message);
        if (messageHistory.Count > maxMessages)
            messageHistory.RemoveAt(0);   // drop the oldest

        logText.text = string.Join("\n", messageHistory);
    }

    async void OnApplicationQuit()
    {
        if (websocket != null && websocket.State == WebSocketState.Open)
            await websocket.Close();
    }
}

